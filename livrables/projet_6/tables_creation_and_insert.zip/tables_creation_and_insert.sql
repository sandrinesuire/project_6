DROP TABLE IF EXISTS pizzapp_address CASCADE;
DROP EXTENSION IF EXISTS postgis;
DROP TABLE IF EXISTS spatial_ref_sys CASCADE;


DO $$DECLARE r record;
BEGIN

    FOR r IN SELECT schemaname, tablename
          FROM pg_tables WHERE NOT schemaname IN ('pg_catalog', 'information_schema')
    LOOP
        EXECUTE 'DROP TABLE ' || quote_ident(r.schemaname) || '.' || quote_ident(r.tablename) || ' CASCADE;';
    END LOOP;

	FOR r IN SELECT sequence_schema, sequence_name
          FROM information_schema.sequences WHERE NOT sequence_schema IN ('pg_catalog', 'information_schema')
    LOOP
        EXECUTE 'DROP SEQUENCE '|| quote_ident(r.sequence_schema) || '.' || quote_ident(r.sequence_name) ||' ';
    END LOOP;
END$$;

CREATE EXTENSION postgis;

CREATE TABLE "public"."pizzapp_address"  (
	"id"             	serial NOT NULL,
	"address_one"    	varchar(400) NOT NULL,
	"address_two"    	varchar(400) NULL,
	"zip_code"       	varchar(20) NOT NULL,
	"city"           	varchar(100) NOT NULL,
	"country"        	varchar(100) NULL,
	"location"       	"public"."geometry" NULL,
	"google_place_id"	text NULL,
	"loc_address"    	text NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_command"  (
	"id"               	serial NOT NULL,
	"delay"            	timestamp with time zone NULL,
	"is_active"        	boolean NOT NULL DEFAULT TRUE,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"  	timestamp with time zone NULL,
	"comment"          	text NULL,
	"employed_id"      	integer NULL,
	"supplier_id"      	integer NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_commandline"  (
	"id"                	serial NOT NULL,
	"quantity"          	numeric(8,3) NULL,
	"delay"             	timestamp with time zone NOT NULL,
	"is_active"         	boolean NOT NULL DEFAULT TRUE,
	"registration_date" 	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"   	timestamp with time zone NULL,
	"comment"           	text NULL,
	"command_id"        	integer NOT NULL,
	"component_id"      	integer NOT NULL,
	"unit_of_measure_id"	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_component"  (
	"id"                	serial NOT NULL,
	"name"              	varchar(100) NOT NULL,
	"stock"             	numeric(8,3) NOT NULL DEFAULT 0,
	"in_command"        	numeric(8,3) NOT NULL DEFAULT 0,
	"reserved"        	    numeric(8,3) NOT NULL DEFAULT 0,
	"is_active"         	boolean NOT NULL DEFAULT TRUE,
	"registration_date" 	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"   	timestamp with time zone NULL,
	"comment"           	text NULL,
	"unit_of_measure_id"	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_componentprice"  (
	"id"                 	serial NOT NULL,
	"cost_price_currency"	varchar(3) NOT NULL DEFAULT 'EUR',
	"cost_price"         	numeric(7,2) NOT NULL,
	"is_active"          	boolean NOT NULL DEFAULT TRUE,
	"registration_date"  	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"    	timestamp with time zone NULL,
	"comment"            	text NULL,
	"component_id"       	integer NOT NULL,
	"supplier_id"        	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_contact"  (
	"id"               	serial NOT NULL,
	"is_active"        	boolean NOT NULL DEFAULT TRUE,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"  	timestamp with time zone NULL,
	"comment"          	text NULL,
	"person_id"        	integer NOT NULL,
	"supplier_id"      	integer NOT NULL,
	PRIMARY KEY("id")
);
CREATE TABLE "public"."pizzapp_customer"  (
	"id"               	serial NOT NULL,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"comment"          	text NULL,
	"person_id"        	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_employed"  (
	"id"               	serial NOT NULL,
	"is_active"        	boolean NOT NULL DEFAULT TRUE,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"  	timestamp with time zone NULL,
	"comment"          	text NULL,
	"person_id"        	integer NOT NULL,
	"pizzeria_id"      	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_employed_roles"  (
	"id"         	serial NOT NULL,
	"employed_id"	integer NOT NULL,
	"role_id"    	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_order"  (
	"id"               	serial NOT NULL,
	"delay"            	timestamp with time zone NOT NULL,
	"is_active"        	boolean NOT NULL DEFAULT TRUE,
	"is_paid"        	boolean NOT NULL DEFAULT FALSE,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"  	timestamp with time zone NULL,
	"comment"          	text NULL,
	"customer_id"      	integer NOT NULL,
	"employed_id"      	integer NULL,
	"pizzeria_id"      	integer NOT NULL,
	"status_id"        	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_orderline"  (
	"id"               	serial NOT NULL,
	"quantity"         	integer NOT NULL DEFAULT 1,
	"is_active"        	boolean NOT NULL DEFAULT TRUE,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"  	timestamp with time zone NULL,
	"comment"          	text NULL,
	"order_id"         	integer NOT NULL,
	"pizza_id"         	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_payment"  (
	"id"               	serial NOT NULL,
	"montant_currency" 	varchar(3) NOT NULL DEFAULT 'EUR',
	"montant"          	numeric(7,2) NOT NULL,
	"is_active"        	boolean NOT NULL DEFAULT TRUE,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"  	timestamp with time zone NULL,
	"comment"          	text NULL,
	"order_id"         	integer NOT NULL,
	"payment_method_id"	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_paymentmethod"  (
	"id"         	serial NOT NULL,
	"short_name" 	varchar(20) NOT NULL,
	"description"	varchar(100) NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_person"  (
	"id"          	serial NOT NULL,
	"first_name"  	varchar(100) NULL,
	"last_name"   	varchar(100) NULL,
	"phone_number"	varchar(50) NULL,
	"email"       	varchar(50) NULL,
	"password"    	varchar(100) NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_pizza"  (
	"id"               	serial NOT NULL,
	"name"             	varchar(100) NOT NULL,
	"price_currency"   	varchar(3) NOT NULL DEFAULT 'EUR',
	"price"            	numeric(7,2) NOT NULL,
	"is_active"        	boolean NOT NULL DEFAULT TRUE,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"  	timestamp with time zone NULL,
	"comment"          	text NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_pizzacard"  (
	"id"               	serial NOT NULL,
	"name"             	varchar(100) NOT NULL,
	"is_active"        	boolean NOT NULL DEFAULT TRUE,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"  	timestamp with time zone NULL,
	"comment"          	text NULL,
	"employed_id"      	integer NOT NULL,
	"pizzeria_id"      	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_pizzacard_pizzas"  (
	"id"          	serial NOT NULL,
	"pizzacard_id"	integer NOT NULL,
	"pizza_id"    	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_pizzaline"  (
	"id"                	serial NOT NULL,
	"quantity"          	numeric(8,3) NOT NULL,
	"is_active"         	boolean NOT NULL DEFAULT TRUE,
	"registration_date" 	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"   	timestamp with time zone NULL,
	"comment"           	text NULL,
	"component_id"      	integer NOT NULL,
	"pizza_id"          	integer NOT NULL,
	"unit_of_measure_id"	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_pizzeria"  (
	"id"        	serial NOT NULL,
	"name"      	varchar(100) NOT NULL,
	"address_id"	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_role"  (
	"id"         	serial NOT NULL,
	"short_name" 	varchar(100) NOT NULL,
	"description"	text NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_status"  (
	"id"         	serial NOT NULL,
	"short_name" 	varchar(20) NOT NULL,
	"description"	varchar(100) NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_stockmovement"  (
	"id"                	serial NOT NULL,
	"quantity"          	numeric(8,3) NOT NULL DEFAULT 0,
	"stock_before"      	numeric(8,3) NOT NULL DEFAULT 0,
	"stock_after"       	numeric(8,3) NOT NULL DEFAULT 0,
	"is_active"         	boolean NOT NULL DEFAULT TRUE,
	"registration_date" 	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"   	timestamp with time zone NULL,
	"comment"           	text NULL,
	"command_line_id"   	integer NULL,
	"component_id"      	integer NOT NULL,
	"order_line_id"     	integer NULL,
	"unit_of_measure_id"	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_supplier"  (
	"id"               	serial NOT NULL,
	"company_name"     	varchar(100) NOT NULL,
	"phone_number"     	varchar(50) NULL,
	"email"            	varchar(50) NULL,
	"is_active"        	boolean NOT NULL DEFAULT TRUE,
	"registration_date"	timestamp with time zone NOT NULL DEFAULT NOW(),
	"inactivity_date"  	timestamp with time zone NULL,
	"comment"          	text NULL,
	"address_id"       	integer NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_typeaddress"  (
	"id"         	serial NOT NULL,
	"type"       	varchar(100) NOT NULL,
	"address_id" 	integer NOT NULL,
	"customer_id"	integer NOT NULL,
	PRIMARY KEY("id")
);


CREATE TABLE "public"."pizzapp_unitofmeasure"  (
	"id"         	serial NOT NULL,
	"short_name" 	varchar(20) NOT NULL,
	"description"	varchar(100) NULL,
	PRIMARY KEY("id")
);



CREATE INDEX "pizzapp_address_google_place_id_like"
	ON "public"."pizzapp_address" (google_place_id);
CREATE INDEX "pizzapp_address_location_id"
	ON "public"."pizzapp_address" (location);
CREATE INDEX "pizzapp_command_employed_id"
	ON "public"."pizzapp_command" (employed_id);
CREATE INDEX "pizzapp_command_supplier_id"
	ON "public"."pizzapp_command" (supplier_id);
CREATE INDEX "pizzapp_commandline_command_id"
	ON "public"."pizzapp_commandline" (command_id);
CREATE INDEX "pizzapp_commandline_component_id"
	ON "public"."pizzapp_commandline" (component_id);
CREATE INDEX "pizzapp_commandline_unit_of_measure_id"
	ON "public"."pizzapp_commandline" (unit_of_measure_id);
CREATE INDEX "pizzapp_component_unit_of_measure_id"
	ON "public"."pizzapp_component" (unit_of_measure_id);
CREATE INDEX "pizzapp_componentprice_component_id"
	ON "public"."pizzapp_componentprice" (component_id);
CREATE INDEX "pizzapp_componentprice_supplier_id"
	ON "public"."pizzapp_componentprice" (supplier_id);
CREATE INDEX "pizzapp_contact_supplier_id"
	ON "public"."pizzapp_contact" (supplier_id);
CREATE INDEX "pizzapp_employed_pizzeria_id"
	ON "public"."pizzapp_employed" (pizzeria_id);
CREATE INDEX "pizzapp_employed_roles_employed_id"
	ON "public"."pizzapp_employed_roles" (employed_id);
CREATE INDEX "pizzapp_employed_roles_role_id"
	ON "public"."pizzapp_employed_roles" (role_id);
CREATE INDEX "pizzapp_order_customer_id"
	ON "public"."pizzapp_order" (customer_id);
CREATE INDEX "pizzapp_order_employed_id"
	ON "public"."pizzapp_order" (employed_id);
CREATE INDEX "pizzapp_order_pizzeria_id"
	ON "public"."pizzapp_order" (pizzeria_id);
CREATE INDEX "pizzapp_order_status_id"
	ON "public"."pizzapp_order" (status_id);
CREATE INDEX "pizzapp_orderline_order_id"
	ON "public"."pizzapp_orderline" (order_id);
CREATE INDEX "pizzapp_orderline_pizza_id"
	ON "public"."pizzapp_orderline" (pizza_id);
CREATE INDEX "pizzapp_payment_order_id"
	ON "public"."pizzapp_payment" (order_id);
CREATE INDEX "pizzapp_payment_payment_method_id"
	ON "public"."pizzapp_payment" (payment_method_id);
CREATE INDEX "pizzapp_paymentmethod_short_name"
	ON "public"."pizzapp_paymentmethod" (short_name);
CREATE INDEX "pizzapp_person_email"
	ON "public"."pizzapp_person" (email);
CREATE INDEX "pizzapp_pizza_name"
	ON "public"."pizzapp_pizza" (name);
CREATE INDEX "pizzapp_pizzacard_employed_id"
	ON "public"."pizzapp_pizzacard" (employed_id);
CREATE INDEX "pizzapp_pizzacard_pizzeria_id"
	ON "public"."pizzapp_pizzacard" (pizzeria_id);
CREATE INDEX "pizzapp_pizzacard_pizzas_pizza_id"
	ON "public"."pizzapp_pizzacard_pizzas" (pizza_id);
CREATE INDEX "pizzapp_pizzacard_pizzas_pizzacard_id"
	ON "public"."pizzapp_pizzacard_pizzas" (pizzacard_id);
CREATE INDEX "pizzapp_pizzaline_component_id"
	ON "public"."pizzapp_pizzaline" (component_id);
CREATE INDEX "pizzapp_pizzaline_pizza_id"
	ON "public"."pizzapp_pizzaline" (pizza_id);
CREATE INDEX "pizzapp_pizzaline_unit_of_measure_id"
	ON "public"."pizzapp_pizzaline" (unit_of_measure_id);
CREATE INDEX "pizzapp_pizzeria_address_id"
	ON "public"."pizzapp_pizzeria" (address_id);
CREATE INDEX "pizzapp_role_short_name"
	ON "public"."pizzapp_role" (short_name);
CREATE INDEX "pizzapp_status_short_name"
	ON "public"."pizzapp_status" (short_name);
CREATE INDEX "pizzapp_stockmovement_command_line_id"
	ON "public"."pizzapp_stockmovement" (command_line_id);
CREATE INDEX "pizzapp_stockmovement_component_id"
	ON "public"."pizzapp_stockmovement" (component_id);
CREATE INDEX "pizzapp_stockmovement_order_line_id"
	ON "public"."pizzapp_stockmovement" (order_line_id);
CREATE INDEX "pizzapp_stockmovement_unit_of_measure_id"
	ON "public"."pizzapp_stockmovement" (unit_of_measure_id);
CREATE INDEX "pizzapp_supplier_type_address_id"
	ON "public"."pizzapp_supplier" (address_id);
CREATE INDEX "pizzapp_typeaddress_address_id"
	ON "public"."pizzapp_typeaddress" (address_id);
CREATE INDEX "pizzapp_typeaddress_customer_id"
	ON "public"."pizzapp_typeaddress" (customer_id);
CREATE INDEX "pizzapp_unitofmeasure_short_name"
	ON "public"."pizzapp_unitofmeasure" (short_name);
ALTER TABLE "public"."pizzapp_address"
	ADD CONSTRAINT "pizzapp_address_google_place_id_key"
	UNIQUE ("google_place_id");
ALTER TABLE "public"."pizzapp_contact"
	ADD CONSTRAINT "pizzapp_contact_person_id_key"
	UNIQUE ("person_id");
ALTER TABLE "public"."pizzapp_customer"
	ADD CONSTRAINT "pizzapp_customer_person_id_key"
	UNIQUE ("person_id");
ALTER TABLE "public"."pizzapp_employed"
	ADD CONSTRAINT "pizzapp_employed_person_id_key"
	UNIQUE ("person_id");
ALTER TABLE "public"."pizzapp_employed_roles"
	ADD CONSTRAINT "pizzapp_employed_roles_employed_id_role_id_uniq"
	UNIQUE ("employed_id", "role_id");
ALTER TABLE "public"."pizzapp_paymentmethod"
	ADD CONSTRAINT "pizzapp_paymentmethod_short_name_key"
	UNIQUE ("short_name");
ALTER TABLE "public"."pizzapp_person"
	ADD CONSTRAINT "pizzapp_person_email_key"
	UNIQUE ("email");
ALTER TABLE "public"."pizzapp_pizza"
	ADD CONSTRAINT "pizzapp_pizza_name_key"
	UNIQUE ("name");
ALTER TABLE "public"."pizzapp_pizzacard_pizzas"
	ADD CONSTRAINT "pizzapp_pizzacard_pizzas_pizzacard_id_pizza_id_uniq"
	UNIQUE ("pizzacard_id", "pizza_id");
ALTER TABLE "public"."pizzapp_role"
	ADD CONSTRAINT "pizzapp_role_short_name_key"
	UNIQUE ("short_name");
ALTER TABLE "public"."pizzapp_status"
	ADD CONSTRAINT "pizzapp_status_short_name_key"
	UNIQUE ("short_name");
ALTER TABLE "public"."pizzapp_unitofmeasure"
	ADD CONSTRAINT "pizzapp_unitofmeasure_short_name_key"
	UNIQUE ("short_name");
ALTER TABLE "public"."pizzapp_command"
	ADD CONSTRAINT "pizzapp_command_supplier_id_fk_pizzapp_supplier_id"
	FOREIGN KEY("supplier_id")
	REFERENCES "public"."pizzapp_supplier"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_command"
	ADD CONSTRAINT "pizzapp_command_employed_id_fk_pizzapp_employed_id"
	FOREIGN KEY("employed_id")
	REFERENCES "public"."pizzapp_employed"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_commandline"
	ADD CONSTRAINT "pizzapp_commandline_unit_of_measure_id_fk_pizzapp_u"
	FOREIGN KEY("unit_of_measure_id")
	REFERENCES "public"."pizzapp_unitofmeasure"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_commandline"
	ADD CONSTRAINT "pizzapp_commandline_component_id_fk_pizzapp_c"
	FOREIGN KEY("component_id")
	REFERENCES "public"."pizzapp_component"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_commandline"
	ADD CONSTRAINT "pizzapp_commandline_command_id_fk_pizzapp_command_id"
	FOREIGN KEY("command_id")
	REFERENCES "public"."pizzapp_command"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_component"
	ADD CONSTRAINT "pizzapp_component_unit_of_measure_id_fk_pizzapp_u"
	FOREIGN KEY("unit_of_measure_id")
	REFERENCES "public"."pizzapp_unitofmeasure"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_componentprice"
	ADD CONSTRAINT "pizzapp_componentpri_supplier_id_fk_pizzapp_s"
	FOREIGN KEY("supplier_id")
	REFERENCES "public"."pizzapp_supplier"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_componentprice"
	ADD CONSTRAINT "pizzapp_componentpri_component_id_fk_pizzapp_c"
	FOREIGN KEY("component_id")
	REFERENCES "public"."pizzapp_component"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_contact"
	ADD CONSTRAINT "pizzapp_contact_supplier_id_fk_pizzapp_supplier_id"
	FOREIGN KEY("supplier_id")
	REFERENCES "public"."pizzapp_supplier"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_contact"
	ADD CONSTRAINT "pizzapp_contact_person_id_fk_pizzapp_person_id"
	FOREIGN KEY("person_id")
	REFERENCES "public"."pizzapp_person"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_customer"
	ADD CONSTRAINT "pizzapp_customer_person_id_fk_pizzapp_person_id"
	FOREIGN KEY("person_id")
	REFERENCES "public"."pizzapp_person"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_employed"
	ADD CONSTRAINT "pizzapp_employed_pizzeria_id_fk_pizzapp_pizzeria_id"
	FOREIGN KEY("pizzeria_id")
	REFERENCES "public"."pizzapp_pizzeria"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_employed"
	ADD CONSTRAINT "pizzapp_employed_person_id_fk_pizzapp_person_id"
	FOREIGN KEY("person_id")
	REFERENCES "public"."pizzapp_person"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_employed_roles"
	ADD CONSTRAINT "pizzapp_employed_roles_role_id_fk_pizzapp_role_id"
	FOREIGN KEY("role_id")
	REFERENCES "public"."pizzapp_role"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_employed_roles"
	ADD CONSTRAINT "pizzapp_employed_rol_employed_id_fk_pizzapp_e"
	FOREIGN KEY("employed_id")
	REFERENCES "public"."pizzapp_employed"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_order"
	ADD CONSTRAINT "pizzapp_order_status_id_fk_pizzapp_status_id"
	FOREIGN KEY("status_id")
	REFERENCES "public"."pizzapp_status"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_order"
	ADD CONSTRAINT "pizzapp_order_pizzeria_id_fk_pizzapp_pizzeria_id"
	FOREIGN KEY("pizzeria_id")
	REFERENCES "public"."pizzapp_pizzeria"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_order"
	ADD CONSTRAINT "pizzapp_order_employed_id_fk_pizzapp_employed_id"
	FOREIGN KEY("employed_id")
	REFERENCES "public"."pizzapp_employed"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_order"
	ADD CONSTRAINT "pizzapp_order_customer_id_fk_pizzapp_customer_id"
	FOREIGN KEY("customer_id")
	REFERENCES "public"."pizzapp_customer"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_orderline"
	ADD CONSTRAINT "pizzapp_orderline_pizza_id_fk_pizzapp_pizza_id"
	FOREIGN KEY("pizza_id")
	REFERENCES "public"."pizzapp_pizza"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_orderline"
	ADD CONSTRAINT "pizzapp_orderline_order_id_fk_pizzapp_order_id"
	FOREIGN KEY("order_id")
	REFERENCES "public"."pizzapp_order"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_payment"
	ADD CONSTRAINT "pizzapp_payment_payment_method_id_fk_pizzapp_p"
	FOREIGN KEY("payment_method_id")
	REFERENCES "public"."pizzapp_paymentmethod"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_payment"
	ADD CONSTRAINT "pizzapp_payment_order_id_fk_pizzapp_order_id"
	FOREIGN KEY("order_id")
	REFERENCES "public"."pizzapp_order"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_pizzacard"
	ADD CONSTRAINT "pizzapp_pizzacard_pizzeria_id_fk_pizzapp_pizzeria_id"
	FOREIGN KEY("pizzeria_id")
	REFERENCES "public"."pizzapp_pizzeria"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_pizzacard"
	ADD CONSTRAINT "pizzapp_pizzacard_employed_id_fk_pizzapp_employed_id"
	FOREIGN KEY("employed_id")
	REFERENCES "public"."pizzapp_employed"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_pizzacard_pizzas"
	ADD CONSTRAINT "pizzapp_pizzacard_pizzas_pizza_id_fk_pizzapp_pizza_id"
	FOREIGN KEY("pizza_id")
	REFERENCES "public"."pizzapp_pizza"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_pizzacard_pizzas"
	ADD CONSTRAINT "pizzapp_pizzacard_pi_pizzacard_id_fk_pizzapp_p"
	FOREIGN KEY("pizzacard_id")
	REFERENCES "public"."pizzapp_pizzacard"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_pizzaline"
	ADD CONSTRAINT "pizzapp_pizzaline_unit_of_measure_id_fk_pizzapp_u"
	FOREIGN KEY("unit_of_measure_id")
	REFERENCES "public"."pizzapp_unitofmeasure"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_pizzaline"
	ADD CONSTRAINT "pizzapp_pizzaline_pizza_id_fk_pizzapp_pizza_id"
	FOREIGN KEY("pizza_id")
	REFERENCES "public"."pizzapp_pizza"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_pizzaline"
	ADD CONSTRAINT "pizzapp_pizzaline_component_id_fk_pizzapp_component_id"
	FOREIGN KEY("component_id")
	REFERENCES "public"."pizzapp_component"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_pizzeria"
	ADD CONSTRAINT "pizzapp_pizzeria_address_id_fk_pizzapp_address_id"
	FOREIGN KEY("address_id")
	REFERENCES "public"."pizzapp_address"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_stockmovement"
	ADD CONSTRAINT "pizzapp_stockmovemen_unit_of_measure_id_fk_pizzapp_u"
	FOREIGN KEY("unit_of_measure_id")
	REFERENCES "public"."pizzapp_unitofmeasure"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_stockmovement"
	ADD CONSTRAINT "pizzapp_stockmovemen_order_line_id_fk_pizzapp_o"
	FOREIGN KEY("order_line_id")
	REFERENCES "public"."pizzapp_orderline"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_stockmovement"
	ADD CONSTRAINT "pizzapp_stockmovemen_component_id_fk_pizzapp_c"
	FOREIGN KEY("component_id")
	REFERENCES "public"."pizzapp_component"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_stockmovement"
	ADD CONSTRAINT "pizzapp_stockmovemen_command_line_id_fk_pizzapp_c"
	FOREIGN KEY("command_line_id")
	REFERENCES "public"."pizzapp_commandline"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_supplier"
	ADD CONSTRAINT "pizzapp_supplier_address_id_fk_pizzapp_address_id"
	FOREIGN KEY("address_id")
	REFERENCES "public"."pizzapp_address"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_typeaddress"
	ADD CONSTRAINT "pizzapp_typeaddress_customer_id_fk_pizzapp_customer_id"
	FOREIGN KEY("customer_id")
	REFERENCES "public"."pizzapp_customer"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;
ALTER TABLE "public"."pizzapp_typeaddress"
	ADD CONSTRAINT "pizzapp_typeaddress_address_id_fk_pizzapp_address_id"
	FOREIGN KEY("address_id")
	REFERENCES "public"."pizzapp_address"("id")
	MATCH SIMPLE
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	DEFERRABLE
	INITIALLY DEFERRED ;


INSERT INTO pizzapp_role (id, short_name, description) VALUES
(1, 'supervisor', 'supervisor role'),
(2, 'administrator', 'administrator role'),
(3, 'operator', 'operator role'),
(4, 'pizzaiolo', 'pizzaiolo role'),
(5, 'deliver', 'deliver role');

INSERT INTO pizzapp_address (id, address_one, zip_code, city, location, google_place_id, loc_address) VALUES
(1, '11 boulevard de verdun', '01300', 'belley', ST_MakePoint(45.760918, 5.686596), 'ChIJ7X66Dy0Ti0cROeAG4sHlcbw', '11 boulevard de verdun 01300 belley'),
(2, '12 boulevard de verdun', '01300', 'belley', ST_MakePoint(45.7606954, 5.6869109), 'EiwxMiBCb3VsZXZhcmQgZGUgVmVyZHVuLCAwMTMwMCBCZWxsZXksIEZyYW5jZSIaEhgKFAoSCc3IsAQtE4tHEZAdWNIMa_EoEAw', '12 boulevard de verdun 01300 belley'),
(3, '13 boulevard de verdun', '01300', 'belley', ST_MakePoint(45.7611091, 5.6866318), 'ChIJtZf2EC0Ti0cRFrnjBc2uQcE', '13 boulevard de verdun 01300 belley'),
(4, '14 boulevard de verdun', '01300', 'belley', ST_MakePoint(45.760647, 5.6869401), 'ChIJKQc7Ai0Ti0cRt1-pmsWAOW0', '14 boulevard de verdun 01300 belley'),
(5, '15 boulevard de verdun', '01300', 'belley', ST_MakePoint(45.7609308, 5.6869321), 'ChIJv6HXHC0Ti0cRdZ2U1B6wShw', '15 boulevard de verdun 01300 belley');

INSERT INTO pizzapp_pizzeria (id, name, address_id) VALUES
(1, 'pizzeria peone', 1),
(2, 'pizzeria napoleon', 4);

INSERT INTO pizzapp_person (id, first_name, last_name, phone_number, email, password) VALUES
(1, 'alfred', 'hitch', '+33 6 52 99 33 66', 'alfred.hitch@gmail.com', 'pbkdf2_sha256$150000$uNbsggi8waUw$YE8GY74/du2qRVSbQT+TaFdmSkYzno/b1VEukUbftAo='),
(2, 'camille', 'deter', '', 'camille.deter@gmail.com', 'pbkdf2_sha256$150000$uNbsggi8waUw$YE8GY74/du2qRVSbQT+TaFdmSkYzno/b1VEukUbftAo='),
(3, 'claudio', 'cappell', '+33 6 52 99 33 62', 'claudio.capel@gmail.com', 'pbkdf2_sha256$150000$uNbsggi8waUw$YE8GY74/du2qRVSbQT+TaFdmSkYzno/b1VEukUbftAo='),
(4, 'tartine', 'hubbert', '+33 6 52 99 33 64', 'tartine.hubert@gmail.com', 'pbkdf2_sha256$150000$uNbsggi8waUw$YE8GY74/du2qRVSbQT+TaFdmSkYzno/b1VEukUbftAo='),
(5, 'madeleine', 'bizz', '', 'madeleine.bizz@gmail.com', 'pbkdf2_sha256$150000$uNbsggi8waUw$YE8GY74/du2qRVSbQT+TaFdmSkYzno/b1VEukUbftAo=');

INSERT INTO pizzapp_customer (id, person_id, comment) VALUES
(1, 1, ''),
(2, 3, '');

INSERT INTO pizzapp_typeaddress (id, type, address_id, customer_id) VALUES
(1, 'house', 2, 1),
(2, 'delivery', 3, 2);

INSERT INTO pizzapp_employed (id, person_id, pizzeria_id) VALUES
(1, 2, 1),
(2, 4, 2);

INSERT INTO pizzapp_employed_roles (employed_id, role_id) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(2, 5);


INSERT INTO pizzapp_supplier (id, company_name, phone_number, email, address_id) VALUES
(1, 'metra', '+33 4 50 42 25 24', 'metra-belley@gmail.com', 5);

INSERT INTO pizzapp_contact (id, person_id, supplier_id) VALUES
(1, 5, 1);

INSERT INTO pizzapp_unitofmeasure (id, short_name, description) VALUES
(1, 'liter', ' by liter'),
(2, 'kg', 'by weight'),
(3, 'unit', 'by piece');

INSERT INTO pizzapp_component (id, name, unit_of_measure_id, stock, in_command, reserved) VALUES
(1, 'cheese', 2, 9.73, 0, 0.18),
(2, 'tomatoes sauce', 1, 2.85, 2, 0.15),
(3, 'ham', 2, 5.80, 0, 0.10),
(4, 'box', 3, 97, 50, 3),
(5, 'dough', 3, 77, 20, 3);

INSERT INTO pizzapp_componentprice (id, component_id, cost_price, supplier_id) VALUES
(1, 1, 2.5, 1),
(2, 2, 5.2, 1),
(3, 3, 3.5, 1),
(4, 4, 0.25, 1),
(5, 5, 0.75, 1);

INSERT INTO pizzapp_pizza (id, name, price) VALUES
(1, 'marguaret', 8.20),
(2, 'ham', 9.00),
(3, 'ham-chees', 9.50);

INSERT INTO pizzapp_pizzaline (pizza_id, component_id, unit_of_measure_id, quantity) VALUES
(1, 5, 3, 1),
(1, 2, 1, 0.05),
(1, 1, 2, 0.06),
(1, 4, 3, 1),
(2, 5, 3, 1),
(2, 2, 1, 0.05),
(2, 1, 2, 0.06),
(2, 3, 2, 0.10),
(2, 4, 3, 1),
(3, 5, 3, 1),
(3, 2, 1, 0.05),
(3, 3, 2, 0.10),
(3, 1, 2, 0.15),
(3, 4, 3, 1);

INSERT INTO pizzapp_pizzacard (id, name, pizzeria_id, employed_id) VALUES
(1, 'summer card', 1, 1),
(2, 'year card', 2, 2);

INSERT INTO pizzapp_pizzacard_pizzas (pizzacard_id, pizza_id) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 2),
(2, 3);

INSERT INTO pizzapp_status (id, short_name, description) VALUES
(1, 'not_started', 'not started'),
(2, 'in_progress', 'in progress'),
(3, 'in_stand', 'in stand of delivery'),
(4, 'deliver', 'deliver'),
(5, 'canceled', 'canceled');

INSERT INTO pizzapp_order (id, status_id, customer_id, employed_id, pizzeria_id, delay) VALUES
(1, 1, 1, 1, 1, '2019-05-31 12:00:00.000000+00'),
(2, 2, 2, 1, 1, '2019-05-31 12:00:00.000000+00'),
(3, 5, 1, 1, 1, '2019-05-31 12:00:00.000000+00'),
(4, 4, 2, 2, 2, '2019-05-31 12:00:00.000000+00');

INSERT INTO pizzapp_orderline (id, order_id, pizza_id) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 1),
(4, 3, 2),
(5, 4, 1),
(6, 4, 2),
(7, 4, 3);

INSERT INTO pizzapp_paymentmethod (id, short_name, description) VALUES
(1, 'cb', 'bank card'),
(2, 'cash', 'cash'),
(3, 'check', 'bank check');

INSERT INTO pizzapp_payment (payment_method_id, order_id, montant) VALUES
(1, 1, 17.20),
(2, 2, 8.20),
(3, 4, 26.70);

INSERT INTO pizzapp_command (id, supplier_id, employed_id) VALUES
(1, 1, 1),
(2, 1, 1),
(3, 1, 2);

INSERT INTO pizzapp_commandline (id, command_id, component_id, unit_of_measure_id, quantity, delay) VALUES
(1, 1, 1, 2, 10, '2019-05-28 12:00:00.000000+00'),
(2, 1, 2, 1, 3, '2019-05-28 12:00:00.000000+00'),
(3, 1, 3, 2, 6, '2019-05-28 12:00:00.000000+00'),
(4, 1, 4, 3, 100, '2019-05-28 12:00:00.000000+00'),
(5, 1, 5, 3, 80, '2019-05-28 12:00:00.000000+00'),
(6, 2, 2, 1, 2, '2019-06-02 12:00:00.000000+00'),
(7, 2, 4, 3, 50, '2019-06-02 12:00:00.000000+00'),
(8, 3, 5, 3, 20, '2019-06-03 12:00:00.000000+00');

INSERT INTO pizzapp_stockmovement (component_id, order_line_id, command_line_id, unit_of_measure_id, quantity, stock_before, stock_after) VALUES
(1, Null, 1, 2, 10, 0, 10),
(2, Null, 2, 1, 3, 0, 3),
(3, Null, 3, 2, 6, 0, 6),
(4, Null, 4, 3, 100, 0, 100),
(5, Null, 5, 3, 80, 0, 80),
(5, 5, Null, 3, 1, 80, 79),
(2, 5, Null, 1, 0.05, 3, 2.95),
(1, 5, Null, 2, 0.06, 10, 9.94),
(4, 5, Null, 3, 1, 100, 99),
(5, 6, Null, 3, 1, 79, 78),
(2, 6, Null, 1, 0.05, 2.95, 2.90),
(1, 6, Null, 2, 0.06, 9.94, 9.88),
(3, 6, Null, 2, 0.10, 6, 5.9),
(4, 6, Null, 3, 1, 99, 98),
(5, 7, Null, 3, 1, 78, 77),
(2, 7, Null, 1, 0.05, 2.90, 2.85),
(1, 7, Null, 2, 0.15, 9.88, 9.73),
(3, 7, Null, 2, 0.10, 5.9, 5.8),
(4, 7, Null, 3, 1, 98, 97);

